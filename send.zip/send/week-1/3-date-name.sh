#!/bin/bash

date && w