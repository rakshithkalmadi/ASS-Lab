#!/bin/bash

sed -n $2,$3\p $1